const express=require('express');
const mysql=require('mysql2/promise');
const app=express();app.use(express.json());app.use(express.urlencoded({extended:true}));app.use(express.static('public'));
const M={host:'master',user:'root',password:'root',database:'ecommerce'};
const S={host:'slave',user:'root',password:'root',database:'ecommerce'};
app.post('/order',async(req,res)=>{const m=await mysql.createConnection(M);const s=await mysql.createConnection(S);await m.execute("INSERT INTO orders(pelanggan,produk) VALUES(?,?)",[req.body.pelanggan,req.body.produk]);if(req.body.mode==='async'){setTimeout(async()=>{await s.execute("INSERT INTO orders(pelanggan,produk) VALUES(?,?)",[req.body.pelanggan,req.body.produk]);},3000);res.send("Data disimpan di MASTER, replikasi 3 detik.");}else{await s.execute("INSERT INTO orders(pelanggan,produk) VALUES(?,?)",[req.body.pelanggan,req.body.produk]);res.send("Sinkron selesai.");}});
app.get('/master',async(_,res)=>{const c=await mysql.createConnection(M);const[r]=await c.query("select * from orders");res.json(r);});
app.get('/slave',async(_,res)=>{const c=await mysql.createConnection(S);const[r]=await c.query("select * from orders");res.json(r);});
app.listen(3000);